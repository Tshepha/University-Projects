package csc383.busstopbuddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

public class viewStudentInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_driver_info);

    }
    public void logOutButton(View view) {
        Intent intent = new Intent(this, StartingScreen.class);
        startActivity(intent);
    }


    public void Update(View view) {
        Spinner spinner = (Spinner) findViewById(R.id.Spinner);
        String student1 = "Jane Doe";
        String student2 = "LUKE JERIES";
        if (String.valueOf(spinner.getSelectedItem()).equals(student1)) {
            TextView StudentAddress = (TextView) findViewById(R.id.StudentAddress);
            StudentAddress.setText("Stop 1: 111 Main Street \n Stop 2: 222 Main Street \n Stop 3: 333 Brown Road");
            TextView StudentNum = (TextView) findViewById(R.id.StudentNum);
            StudentNum.setText("(810)486-8570");
            TextView SRouteNum = (TextView) findViewById(R.id.SRouteNum);
            SRouteNum.setText("3");

        }

        else if(String.valueOf(spinner.getSelectedItem()).equals(student2)){
            TextView StudentAddress = (TextView) findViewById(R.id.StudentAddress);
            StudentAddress.setText("Stop 1: 542 Leeroy Street");
            TextView StudentNum = (TextView) findViewById(R.id.StudentNum);
            StudentNum.setText("(810)469-2946");
            TextView SRouteNum = (TextView) findViewById(R.id.SRouteNum);
            SRouteNum.setText("1");

        }
    }
}
