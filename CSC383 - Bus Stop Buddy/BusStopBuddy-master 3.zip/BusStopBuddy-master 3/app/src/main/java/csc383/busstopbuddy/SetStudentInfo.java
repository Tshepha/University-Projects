package csc383.busstopbuddy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SetStudentInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_student_info);
    }
}
